import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author Albion Fung
 * @version 0.0.1
 */
public class GameOver extends Actor
{
    /**
     * Screen for game over. No parameters, no function, only shows a picture.
     */
    public void GameOver() 
    {
    }    
}
